// The site description: the one file in a site repository,
// `site-description.json` at its root, that declares the site's content
// model. Astro reads what it declares as typed content collections.
//
// siteDescription() checks a description as declared and returns it in the
// form the readers use. Every problem is named at once, by its path in the
// file; a description with any problem is refused whole.

import { readFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { catalogueFor, INTERFACE_LANGUAGES, labelIn, SOURCE_LANGUAGE } from './catalogues.js';
import { freeze, interfaceLanguagesNamed, isLinkAddress, isObject, label, onlyKeys as checkedKeys, text } from './checks.js';
import { ARTICLE, BUILT_IN_TAXONOMIES, BUILT_IN_TYPES, catalogueLabel, EVERY_STRUCTURED_DATA_TYPE, fieldsWith } from './format/built-in-types.js';
import { IMAGE_LIBRARY_FOLDER, MEDIA_FOLDER } from './format/masters.js';
import { suffixTakenIn } from './format/public-suffixes.js';
import { readComponents, withComponents } from './format/components.js';
import rules from './format/rules.json' with { type: 'json' };
import { coreSettingsGroups, groupsFor, settingsGroups } from './settings-groups.js';
import { isSiteFile, siteJson } from './site-repository.js';

// Where a site keeps its description, relative to the site repository's root.
export const SITE_DESCRIPTION_FILE = 'site-description.json';

// The reserved paths: everything below this prefix, on the site's own host
// and its pre-launch address, belongs to the site's services, its public
// endpoint and its search. No type's address and no page
// of a build may lie there.
export const RESERVED_PREFIX = '/_konzilo/';

// A locale's shape: a language subtag
// of two or three lowercase letters, then a region of two capitals, then a
// variant, such as `fi`, `sv_SE` or `de_DE_formal`.
export const LOCALE = /^[a-z]{2,3}(?:_[A-Z]{2}(?:_[A-Za-z0-9]+)?)?$/;

// The language tag of a locale, as HTML takes it (BCP 47): the locale's first
// two parts joined by a hyphen, `sv-SE` for
// `sv_SE` and `de-DE` for `de_DE_formal`. A site that declares no language,
// whose locale is null, says `en`.
export function languageTag(locale) {
  return locale === null ? 'en' : locale.split('_').slice(0, 2).join('-');
}

// The fields the core gives meaning to, by the name the content file gives
// them, each with the keys it takes. The title is always written, so it is not
// declared. The content format document names each (content-format.md).
export const CORE_FIELDS = Object.freeze({
  date: Object.freeze([]),
  modified: Object.freeze([]),
  excerpt: Object.freeze(['required']),
  image: Object.freeze(['required']),
  // The parts of an article (article-parts.js), each a text but the teaser: the post's
  // name in breadcrumbs, the headline's eyebrow, main headline and subheadline, the
  // standfirst, and the teaser, which shows the post elsewhere, with its image, headline
  // and text.
  breadcrumb: Object.freeze([]),
  eyebrow: Object.freeze([]),
  headline: Object.freeze(['required']),
  subheadline: Object.freeze([]),
  standfirst: Object.freeze(['required']),
  teaser: Object.freeze([]),
});

// The core's fields that hold a plain text, which the intake writes as one.
export const TEXT_FIELDS = Object.freeze(['excerpt', 'breadcrumb', 'eyebrow', 'headline', 'subheadline', 'standfirst']);

// The value types of the site's own fields and settings, and the editor
// controls each may be shown with. A post and an image are a site setting's
// alone: the choice of one published post of a type with an address, written
// as the post's title and current address, and the choice of an image, written
// as its master's address with its alt text. The content format document names
// each type (content-format.md).
export const SETTING_TYPES = Object.freeze({
  string: Object.freeze(['text', 'textarea', 'select']),
  number: Object.freeze(['number']),
  integer: Object.freeze(['number']),
  boolean: Object.freeze(['toggle']),
  date: Object.freeze(['date']),
  post: Object.freeze(['post']),
  image: Object.freeze(['image']),
});

// The type of a setting that chooses a post.
export const POST = 'post';

// The type of a setting that chooses an image.
export const IMAGE = 'image';

// The value types of a post's fields of the site's own, which never choose a
// post or an image.
export const FIELD_TYPES = Object.freeze(Object.fromEntries(Object.entries(SETTING_TYPES).filter(([type]) => type !== POST && type !== IMAGE)));

// The frontmatter key that holds a post's old addresses, the addresses it had
// before its slug changed, in every type with an address. Every
// such post has them, so no field is declared by this name.
export const OLD_ADDRESSES = 'oldAddresses';

// The frontmatter key that holds a post's other addresses, the rules that
// lead to it, in every type with an address.
export const OTHER_ADDRESSES = 'otherAddresses';

// The frontmatter key that names a post's translation set, on a site in
// several languages, when the post has a translation.
export const TRANSLATION_KEY = 'translationKey';

// Konzilo's own field group, the search and sharing fields: `"seo": {}` among
// a type's fields, which takes no keys. These are the frontmatter's `seo` map's
// keys, in the map's order.
export const SEO_FIELD = 'seo';
export const SEO_KEYS = Object.freeze(['title', 'description', 'canonical', 'socialTitle', 'socialDescription', 'socialImage', 'socialImageAlt', 'schema', 'noindex', 'nofollow']);
// How a source file holds them: in three groups, as an editor sees them, each a key of
// the source file's own beside the post's fields, and not as the content file's flat
// map. Each group's keys as the source names them, with the key each is written under;
// the sharing image is { src, alt }, written as `socialImage` and `socialImageAlt`.
export const SEO_PARTS = Object.freeze({
  search: Object.freeze({ title: 'title', description: 'description', canonical: 'canonical', noindex: 'noindex', nofollow: 'nofollow' }),
  sharing: Object.freeze({ image: 'socialImage', title: 'socialTitle', description: 'socialDescription' }),
  structured: Object.freeze({ schema: 'schema' }),
});

// The site's identity: its title, logo and site icon, which settings.json holds
// before the site's own settings, under these names. No setting of the site's own, and no settings
// group of Konzilo's, takes one of them.
export const IDENTITY = Object.freeze(['title', 'logo', 'icon']);

// How an editor writes a type's bodies: as text, in the body field, or as a tree of their
// levels, in the structure field, for bodies built of components.
export const EDITORS = Object.freeze(['text', 'structure']);

// The elements a type's posts may hold in their bodies, by the names in the rule data
// with the site's components (`known`), or any name where `known` is null, the description read
// without the components it takes.
function elementsOf(elements, path, known, problems) {
  if (!Array.isArray(elements) || !elements.every((element) => typeof element === 'string')) {
    problems.push(`${path}: must list the elements the type takes, by name`);
    return [];
  }
  for (const element of elements) {
    if (known !== null && !Object.hasOwn(known.elements, element)) problems.push(`${path}: the core cannot publish the element ${JSON.stringify(element)}`);
  }
  if (new Set(elements).size !== elements.length) problems.push(`${path}: names an element twice`);
  return [...elements];
}

// The structured data types a post may be given in place of its type's
// template, schema.org's names, which the rule data lists.
export const SCHEMA_TYPES = Object.freeze([...rules.structuredDataTypes]);

// The descriptions checked, by the settings groups they were checked with,
// and what siteDescription() returned.
const checked = new WeakMap();
const results = new WeakSet();

// A description as declared (the parsed JSON) to the form the readers use:
//
//   { language: <locale> or null,
//     languages: [ { locale, tag, prefix, main } ],
//     interfaceLanguage: <interface language>,
//     types: { <post type>: { name, builtIn, label, plural, collection, address, feed, hierarchical, search, elements, fields, editor, structuredDataTypes } },
//     taxonomies: { <taxonomy>: { name, builtIn, label, plural, collection, hierarchical, address, feed } },
//     images: { smallestWidth, displayWidth } or null,
//     menus: { <menu>: { name, label } },
//     settings: [ { name, label, type, control, options, required, translated } ],
//     consent: { departures: [ { departure, service, reason } ], domain },
//     security: { includeSubDomains, frameAncestors: [ <origin> ], dataImages },
//     forms: { <form>: { name, label, button, editable, fields: [ { name, label, labelParts, kind, required, maxLength, options, help } ] } },
//     search: { address } or null,
//     components: { <component>: { name, element, label, form, body, attributes } } or null,
//     componentsFrom: <path or package specifier> or null,
//     componentChecks: <path or package specifier> or null,
//     groups: [ { name, label, description, settings, types, each } ] }
//
// The language is the one the site's content is written in, a locale,
// or null for a site that declares none; on a site with several languages, its
// main language. The languages are the site's, in the order declared, the main
// language first: each by its locale (`sv_SE`), its
// language tag (`sv-SE`, languageTag()), its prefix, the first segment of its
// pages' addresses, and whether it is the main language. A prefix is the
// language subtag (`sv`), or the whole tag in lowercase
// (`en-gb`) where another of the site's locales starts with the same subtag,
// as two variants of one language do. A site with one language gives it with
// no prefix (null), and a site that declares none gives none. The interface
// language is the one the editor's interface takes where an editor has chosen
// none (interfaceLanguageOf()). A type named `canvas`, `page` or `article` is the
// core's own, built in (format/built-in-types.js), and `builtIn` names it, null on a
// type of the site's own: the site gives it what it gives any type but its fields, its
// label and plural where it wants its own, and fields of its own, and the type has the
// core's fields, with the site's own before the search and sharing fields. A type's
// `structuredDataTypes` are those its posts may have, its default first: a built-in type's
// the core's, and a type of the site's own's those it declares, else a page's. An article
// brings the built-in taxonomies `authors`, `category` and `topics`, first among the
// taxonomies, to which a site may give an address, a feed and a label of its own; on a
// site without the article, a taxonomy of one of these names is the site's own. Where a
// built-in type or taxonomy has no label of the site's, it has the core's, from the
// catalogues, in the form of a label by language. A label of the site's own, a type's or a
// taxonomy's `label` and `plural`, a menu's, a setting's, a field's, a
// presentation's and its options', and a component's and its attributes', is as
// declared: one text for every language, or an object of a text by interface
// language, `en` among them (checks.js, label()), which catalogues.js's labelIn()
// gives in a language. A form's label and its fields' are one text, since
// visitors read them. A type's address is
// where visitors reach each of its posts, a path from the site's root with
// `{slug}` as its last segment, or `{path}` in a hierarchical type, whose
// posts have parents (format/addresses.js); null for a type whose posts have
// no page of their own. On a site with several languages it may be an object
// of an address by locale, one for each language, as declared. A type's
// `search` says whether its posts are in the site's search: every
// type with an address is, on a site with search, unless it declares
// `"search": false`. A type's `feed` is the address of its RSS feed, and a
// taxonomy's that of each term's, with `{slug}` for the term's slug, or null
// for none. A taxonomy's `address` is where visitors reach each of
// its terms' pages, as a type's is, with `{slug}`, or `{path}` in a
// hierarchical taxonomy, the slugs of the term's parents and its own; null for
// a taxonomy whose terms have no page, which no taxonomy has unless it
// declares one. `components` are the directives the site declares of its
// own, as format/components.js reads them, each an element of the rule data
// that siteRules() gives: those it takes whole from the JSON file
// `componentsFrom` names in the site repository, a package's or its own
// (site-repository.js), with the labels it gives them under `componentLabels`,
// and its own after them; null where the description is read without what it
// takes. `componentChecks` is the module that checks what they hold, a
// package's or the site's own. Each field is { name, kind, required } and what its
// kind needs: `date`, `modified`, `excerpt` and `image`, the core's own; `seo`
// ({ keys }, SEO_KEYS), Konzilo's own; `terms` ({ taxonomy }) or `meta`
// ({ label, type, control, options }). `images`
// gives the widths uploads are checked against: an image narrower than the
// smallest is refused, one narrower than the display width the site usually
// shows images at is warned about. A menu is a place in the site's design,
// named as the design names it, and on a site with several
// languages a place per language. The site settings take the form of a type's
// fields of the site's own, in the order declared, and a text may be
// `translated`, true only when declared, with a value per language. `consent` holds the site's departures from
// the consent rules, each one of DEPARTURES with its reason, a
// necessaryService's naming its service, in the order declared, none for a
// site that declares none; and the domain the consent choice is kept on,
// for every site below it, or null, where each site keeps its own. `security` holds the site's opt-ins to its security
// headers: HSTS for every subdomain of its host too, and the
// origins, each `https://` and a host, that may frame its pages beside its
// own; none for a site that declares none. `forms` are the forms the site
// declares, each by the last segment of its address on the endpoint,
// /_konzilo/forms/<form>, with its label, its button's text, one text, or one
// by locale as declared, or null for the site's word for sending, the texts an
// editor may change where it is placed (EDITABLE_FORM_TEXTS), and its fields in order: each field
// of one of FIELD_KINDS, with whether it is required, a text's `maxLength` in
// characters, a choice's `options` and a `help` text or null. `search` is the
// site's search, the public address of its search page, or null for
// a site without search, which has no search page, box or index. `groups` are
// Konzilo's own settings groups as settingsGroups() reads them, by default the
// core's (settings-groups.js): no setting of the site's own takes the name of
// any of them, and the result's `groups` are those that apply to the site, as
// groupsFor() gives them. `fromSite` gives the JSON of a file of the site
// repository that the description names, the components it takes
// (`componentsFrom`), by its path or its package specifier, and throws where it
// cannot (site-repository.js, siteJson()); readSiteDescription() gives it.
// Without it, the description is read without the components it takes: its
// `components` are null, a type may name any element beside the core's and the
// site's own, and siteRules() refuses it, so that no body is read against it.
// Throws an Error naming every problem. What it returns it takes back as it is.
export function siteDescription(declared, groups = coreSettingsGroups(), fromSite = null) {
  if (results.has(declared)) return declared;
  const read = settingsGroups(groups);
  if (!checked.has(read)) checked.set(read, new WeakMap());
  const known = checked.get(read);
  // What a description takes from the site repository may differ by where it is read.
  const kept = isObject(declared) && declared.componentsFrom === undefined;
  if (kept && known.has(declared)) return known.get(declared);
  const problems = [];
  const result = description(declared, read, fromSite, problems);
  if (problems.length > 0) {
    throw new Error(`the site description is not valid:\n${problems.map((problem) => `  ${problem}`).join('\n')}`);
  }
  if (kept) known.set(declared, result);
  results.add(result);
  return result;
}

// What a post list of the site may name, as format/post-list.js checks a list
// against it:
//
//   { types: { <type>: { plural, taxonomies: [ { name, label } ],
//                        fields: { <field>: { type, options } } } },
//     presentations: { <presentation>: { options: [ { name, type, options, required } ] } } }
//
// A type's plural and its taxonomies' labels are in British English, as the
// refusals that name them are. Its taxonomies are those its fields hold the terms of, in order; its
// fields are those a list filters on and orders by, `date` and `modified`, of
// the type `date`, and the site's own: `text`, `choice` (a
// select, with its options), `boolean`, `number`, `integer` or `date`. A
// presentation's options are of the type `string`, `integer` or `boolean`,
// a select's with its options.
export function postListModel({ types, presentations }) {
  const fieldOf = (field) => {
    if (field.kind === 'date' || field.kind === 'modified') return { type: 'date' };
    if (field.control === 'select') return { type: 'choice', options: field.options ?? [] };
    return { type: field.type === 'string' ? 'text' : field.type };
  };
  return {
    types: Object.fromEntries(Object.values(types).filter(Boolean).map((type) => [type.name, {
      plural: labelIn(type.plural, SOURCE_LANGUAGE),
      taxonomies: type.fields.filter((field) => field.kind === 'terms' && field.taxonomy).map(({ taxonomy }) => ({ name: taxonomy.name, label: labelIn(taxonomy.label, SOURCE_LANGUAGE) })),
      fields: Object.fromEntries(type.fields.filter((field) => ['date', 'modified', 'meta'].includes(field.kind)).map((field) => [field.name, fieldOf(field)])),
    }])),
    presentations: Object.fromEntries(Object.values(presentations ?? {}).filter(Boolean).map((presentation) => [presentation.name, {
      options: presentation.options.map(({ name, type, options, required }) => ({ name, type, ...(options ? { options } : {}), required })),
    }])),
  };
}

// What the site declares that a directive's attribute may name (`declared`
// in the rule data), as format/post-list.js checks such an attribute against
// it: the names of what it declares, by the key they are declared under, `forms` the names
// of its forms; and under `editable`, by the same key, what an editor may change of each where
// it is placed, by its name, such as `{ forms: { contact: ['button'] } }` (`editable` in the
// rule data).
export function declaredNames({ forms }) {
  const declared = Object.values(forms ?? {}).filter(Boolean);
  return {
    forms: Object.keys(forms ?? {}),
    editable: { forms: Object.fromEntries(declared.map((form) => [form.name, [...form.editable]])) },
  };
}

// The site description in a file, checked with `groups` as siteDescription()
// checks it, with what it names in the site repository, the folder that holds
// it.
export function readSiteDescription(file, groups) {
  return siteDescription(declaredIn(file), groups, (value) => siteJson(value, resolve(dirname(file))));
}

// The site description in a file, checked as readSiteDescription() checks it,
// but without the components it takes (`componentsFrom`), for a reader that
// reads no body, such as the service, the seed and the live preview's gate: the
// folder that holds it need not have installed the packages they come from.
// Its `components` are null, and siteRules() refuses it.
export function readSiteDescriptionWithoutTakenComponents(file, groups) {
  return siteDescription(declaredIn(file), groups);
}

// The site description in a file as declared, its JSON.
function declaredIn(file) {
  let text;
  try {
    text = readFileSync(file, 'utf8');
  } catch (error) {
    throw new Error(`the site description cannot be read: ${error.message}`);
  }
  let declared;
  try {
    declared = JSON.parse(text);
  } catch (error) {
    throw new Error(`the site description ${file} is not JSON: ${error.message}`);
  }
  return declared;
}

function description(declared, groups, fromSite, problems) {
  if (!isObject(declared)) {
    problems.push('the site description must be a JSON object');
    return null;
  }
  onlyKeys(declared, ['language', 'languages', 'interfaceLanguage', 'images', 'types', 'taxonomies', 'presentations', 'menus', 'settings', 'consent', 'security', 'forms', 'search', 'components', 'componentsFrom', 'componentLabels', 'componentChecks'], '', problems);
  const { components, componentsFrom } = componentsOf(declared, fromSite, problems);
  const known = components === null ? null : withComponents(rules, components);
  const componentChecks = componentChecksOf(declared.componentChecks, components, problems);
  const languages = languagesOf(declared, problems);
  const language = languages.length > 0 ? languages[0].locale : null;
  const interfaceLanguage = interfaceLanguageOf(declared.interfaceLanguage, language, problems);
  const collections = new Map();
  const addresses = { languages, taken: new Map(), told: new Set(), searched: declared.search !== undefined };
  const taxonomies = {};
  const declaredTaxonomies = entries(declared.taxonomies, 'taxonomies', problems, false);
  // The article's taxonomies come first, as the site gives them or with nothing given.
  const brought = isObject(declared.types) && Object.hasOwn(declared.types, ARTICLE) ? BUILT_IN_TYPES[ARTICLE].taxonomies : [];
  for (const name of brought) {
    const given = declaredTaxonomies.find(([declaredName]) => declaredName === name)?.[1] ?? {};
    taxonomies[name] = builtInTaxonomyOf(name, given, `taxonomies.${name}`, { collections, addresses }, problems);
  }
  // Without the article, a taxonomy of one of their names is the site's own.
  for (const [name, taxonomy] of declaredTaxonomies) {
    if (!brought.includes(name)) taxonomies[name] = taxonomyOf(name, taxonomy, `taxonomies.${name}`, { collections, addresses }, problems);
  }
  const types = {};
  for (const [name, type] of entries(declared.types, 'types', problems, true)) {
    types[name] = typeOf(name, type, `types.${name}`, { collections, taxonomies, addresses, rules: known }, problems);
  }
  feedsOf(types, taxonomies, problems);
  ownFieldsOf(types, problems);
  const presentations = {};
  const optionTypes = new Map();
  for (const [name, presentation] of entries(declared.presentations, 'presentations', problems, false)) {
    presentations[name] = presentationOf(name, presentation, `presentations.${name}`, optionTypes, problems);
  }
  const search = searchOf(declared.search, { types, taxonomies, languages }, problems);
  const images = imagesOf(declared.images, types, problems);
  const menus = {};
  for (const [name, menu] of entries(declared.menus, 'menus', problems, false)) {
    menus[name] = menuOf(name, menu, `menus.${name}`, problems);
  }
  const settings = [];
  for (const [name, setting] of entries(declared.settings, 'settings', problems, false)) {
    const read = settingOf(name, setting, `settings.${name}`, groups, problems);
    if (read) settings.push(read);
  }
  const consent = consentOf(declared.consent, problems);
  const security = securityOf(declared.security, problems);
  const forms = {};
  for (const [name, form] of entries(declared.forms, 'forms', problems, false)) {
    forms[name] = formOf(name, form, `forms.${name}`, languages, problems);
  }
  return freeze({ language, languages, interfaceLanguage, types, taxonomies, presentations, images, menus, settings, consent, security, forms, search, components, componentsFrom, componentChecks, groups: groupsFor(declared, types, groups, language, forms) });
}

// The site's components: those it takes from a package or a file of its repository, named by
// `componentsFrom`, whole, each with the labels the site gives it under `componentLabels`, and
// its own, under `components`, after them; null where it takes some and there is no `fromSite`
// to take them by.
function componentsOf(declared, fromSite, problems) {
  const own = readComponents(declared.components, rules, 'components', problems, label);
  const componentsFrom = siteFileOf(declared.componentsFrom, 'componentsFrom', JSON_FILE, problems);
  const labels = componentLabelsOf(declared.componentLabels, problems);
  if (componentsFrom === null) {
    if (declared.componentLabels !== undefined) problems.push('componentLabels: gives labels to the components the site takes, and it takes none (componentsFrom)');
    return { components: own, componentsFrom };
  }
  if (fromSite === null) return { components: null, componentsFrom };
  const taken = takenComponents(componentsFrom, fromSite, problems);
  if (taken === null) return { components: own, componentsFrom };
  for (const name of Object.keys(own)) {
    if (Object.hasOwn(taken, name)) problems.push(`components.${name}: ${componentsFrom} declares ${name} too, and a site gives a component it takes its labels alone, under componentLabels`);
  }
  for (const [name, given] of Object.entries(labels)) {
    const component = taken[name];
    const at = `componentLabels.${name}`;
    if (!component) {
      problems.push(`${at}: ${componentsFrom} declares no component ${name}`);
      continue;
    }
    if (given.label !== undefined) component.label = labelOver(component.label, given.label, `${at}.label`, problems);
    for (const [attribute, { label: one }] of Object.entries(given.attributes)) {
      const setting = component.attributes[attribute];
      if (setting) setting.label = labelOver(setting.label, one, `${at}.attributes.${attribute}.label`, problems);
      else problems.push(`${at}.attributes.${attribute}: ${name}, as ${componentsFrom} declares it, has no attribute ${attribute}`);
    }
  }
  return { components: { ...taken, ...own }, componentsFrom };
}

// The components a site takes from the file `componentsFrom` names, as readComponents() reads
// them, each problem named by the file, or null where the file cannot be had.
function takenComponents(componentsFrom, fromSite, problems) {
  let declared;
  try {
    declared = fromSite(componentsFrom);
  } catch (error) {
    problems.push(`componentsFrom: ${error.message}`);
    return null;
  }
  if (!isObject(declared)) {
    problems.push(`componentsFrom: ${componentsFrom}: must be an object of components, by name`);
    return null;
  }
  const inFile = [];
  const taken = readComponents(declared, rules, '', inFile, label);
  problems.push(...inFile.map((problem) => `componentsFrom: ${componentsFrom}: ${problem}`));
  return taken;
}

// The files a site description may name in the site repository, each by what it is, `kind`,
// the `extensions` its path ends with, and what the description's checker gives as examples
// where it refuses a value, a path, `pathExample`, and a package specifier, `specifierExample`.
const JSON_FILE = { kind: 'a JSON file', extensions: ['.json'], pathExample: 'components.json', specifierExample: '@example/design/directives/components.json' };
const MODULE = { kind: 'a JavaScript module', extensions: ['.js', '.mjs'], pathExample: 'component-checks.js', specifierExample: '@example/design/directives/checks' };

// A file of the site repository a key names, of a kind above, a path from its root or a package
// specifier (site-repository.js), or null where the key is left out.
function siteFileOf(given, key, { kind, extensions, pathExample, specifierExample }, problems) {
  if (given === undefined) return null;
  if (!isSiteFile(given, extensions)) {
    problems.push(`${key}: must be the path of ${kind} in the site repository, from its root, such as ${pathExample}, or a package specifier, a scoped package's name and the path of a file it exports, such as ${specifierExample}`);
    return null;
  }
  return given;
}

// The labels a site gives the components it takes, as declared: { <component>: { label,
// attributes: { <attribute>: { label } } } }, each label as overLabel() takes it.
function componentLabelsOf(declared, problems) {
  if (declared === undefined) return {};
  const read = {};
  for (const [name, given] of entries(declared, 'componentLabels', problems, false)) {
    const at = `componentLabels.${name}`;
    if (!isObject(given)) {
      problems.push(`${at}: must be an object of the component's label and its attributes'`);
      continue;
    }
    onlyKeys(given, ['label', 'attributes'], at, problems, 'the labels of a component the site takes');
    if (given.label !== undefined) overLabel(given.label, `${at}.label`, problems);
    const attributes = {};
    for (const [attribute, setting] of entries(given.attributes ?? {}, `${at}.attributes`, problems, false)) {
      if (!isObject(setting)) {
        problems.push(`${at}.attributes.${attribute}: must be an object of the attribute's label`);
        continue;
      }
      onlyKeys(setting, ['label'], `${at}.attributes.${attribute}`, problems, 'the label of an attribute of a component the site takes');
      if (setting.label !== undefined) attributes[attribute] = { label: overLabel(setting.label, `${at}.attributes.${attribute}.label`, problems) };
    }
    read[name] = { label: given.label, attributes };
  }
  return read;
}

// A label the site gives over another: one text for every language, or one by interface
// language, which need not give British English where the label it goes over does.
function overLabel(value, path, problems) {
  if (typeof value === 'string') return text(value, path, problems);
  if (!isObject(value)) {
    problems.push(`${path}: must be a non-empty string, or one by interface language, such as { "sv": "Sektion" }`);
    return value;
  }
  for (const [language, one] of Object.entries(value)) {
    if (!INTERFACE_LANGUAGES.includes(language)) problems.push(`${path}.${language}: ${language} is not a language Konzilo's interface comes in, which are ${interfaceLanguagesNamed()}`);
    else text(one, `${path}.${language}`, problems);
  }
  return value;
}

// A label given over another, by language: a text for every language takes its place, and one by
// language takes the place of the other's in its languages, the other's one text its British
// English.
function labelOver(under, over, path, problems) {
  if (typeof over === 'string') return over;
  const merged = { ...(typeof under === 'string' ? { [SOURCE_LANGUAGE]: under } : under ?? {}), ...over };
  if (!Object.hasOwn(merged, SOURCE_LANGUAGE)) problems.push(`${path}: gives no ${SOURCE_LANGUAGE}, the British English a label by language needs, which the component it takes gives none of`);
  return merged;
}

// The rule data a site's bodies are read against: the core's, with the components the
// site declares (format/components.js), for a description as siteDescription() gives it.
// Throws for one read without the components it takes.
const ruled = new WeakMap();
export function siteRules(site) {
  if (site?.components === null) throw new Error('the site description was read without the components it takes (componentsFrom), so no body can be read against it');
  if (!site?.components || Object.keys(site.components).length === 0) return rules;
  if (!ruled.has(site)) ruled.set(site, withComponents(rules, site.components));
  return ruled.get(site);
}

// The module that checks what the site's components hold, a path from the site
// repository's root or a package specifier (site-repository.js), or null for a site that has
// none. Its `componentProblems(name, attributes, blocks)` gives the reasons the site cannot
// publish what a component holds.
function componentChecksOf(given, components, problems) {
  const checks = siteFileOf(given, 'componentChecks', MODULE, problems);
  if (checks !== null && components !== null && Object.keys(components).length === 0) problems.push('componentChecks: checks what the site\'s components hold, and the site declares none');
  return checks;
}

// An origin that may frame the site's pages: `https://` and a host, in
// lowercase, with no port, path or wildcard.
const FRAMING_ORIGIN = /^https:\/\/[a-z0-9](?:[a-z0-9-]*[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)+$/;

// What the site chooses of its security headers: HSTS that
// holds for every subdomain of its host too, which would force HTTPS on the
// customer's every other subdomain, the origins that may frame its pages
// beside its own, and whether its pages may show `data:` images, such as a
// design's icons embedded in its stylesheet, which they may unless
// `dataImages` is false. Nothing else of the headers is the site's.
function securityOf(security, problems) {
  const none = { includeSubDomains: false, frameAncestors: [], dataImages: true };
  if (security === undefined) return none;
  if (!isObject(security)) {
    problems.push('security: must be an object');
    return none;
  }
  onlyKeys(security, ['includeSubDomains', 'frameAncestors', 'dataImages'], 'security', problems);
  const includeSubDomains = flag(security.includeSubDomains, 'security.includeSubDomains', problems);
  const dataImages = flag(security.dataImages, 'security.dataImages', problems, true);
  const declared = security.frameAncestors ?? [];
  if (!Array.isArray(declared)) {
    problems.push('security.frameAncestors: must list the origins that may frame the site');
    return { includeSubDomains, frameAncestors: [], dataImages };
  }
  const frameAncestors = [];
  declared.forEach((origin, index) => {
    const path = `security.frameAncestors.${index + 1}`;
    if (typeof origin !== 'string' || !FRAMING_ORIGIN.test(origin)) {
      problems.push(`${path}: ${JSON.stringify(origin)} is no origin that may frame the site; give https:// and the host in lowercase, with no port, path or wildcard, such as https://www.example.com`);
    } else if (frameAncestors.includes(origin)) {
      problems.push(`${path}: lists ${origin} again`);
    } else {
      frameAncestors.push(origin);
    }
  });
  return { includeSubDomains, frameAncestors, dataImages };
}

// The kinds of a form's field, each with the rules it takes beside its
// name, label and kind, in the order they are checked. A field of a text
// kind takes at most `most` characters, `maxLength` when none is declared.
// An acceptance is a box that must be ticked, such as reading the privacy
// policy, so it is always required; a checkbox is a yes or a no, never
// required.
export const FIELD_KINDS = Object.freeze({
  text: { rules: ['required', 'maxLength', 'help'], maxLength: 200, most: 1000 },
  email: { rules: ['required', 'maxLength', 'help'], maxLength: 254, most: 254 },
  tel: { rules: ['required', 'maxLength', 'help'], maxLength: 50, most: 50 },
  textarea: { rules: ['required', 'maxLength', 'help'], maxLength: 5000, most: 10000 },
  select: { rules: ['required', 'options', 'help'] },
  radio: { rules: ['required', 'options', 'help'] },
  checkbox: { rules: ['help'] },
  checkboxes: { rules: ['required', 'options', 'help'] },
  acceptance: { rules: ['help'], required: true },
});

// The most characters a form's text fields take together, so that a
// submission's body stays within what the endpoint takes.
export const FORM_CHARACTERS = 20000;

// A form's name is the last segment of its address on the endpoint,
// /_konzilo/forms/<form>, and its key in the forms' settings group.
export const FORM_NAME = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/;

// A field's name is its name in the form's HTML and in a submission. The
// endpoint's own fields, such as the page a submission came from, start with
// an underscore, which no declared field may.
const FORM_FIELD_NAME = /^[a-z][a-z0-9_]*$/;

// The texts of a form an editor may change where the form is placed, each as the attribute of
// the form's directive that gives it (rules.json). A placeholder's and a label's wait until a
// site asks for them.
export const EDITABLE_FORM_TEXTS = Object.freeze(['button']);

// A form: its label, which names it to editors, in a notification's subject
// and on the Site settings page; its button's text, null for the site's word
// for sending; the texts an editor may change where the form is placed, of
// EDITABLE_FORM_TEXTS; and its fields in order.
function formOf(name, form, path, languages, problems) {
  if (!FORM_NAME.test(name)) {
    problems.push(`${path}: a form's name must be lowercase letters and digits, with single hyphens inside, starting with a letter`);
  }
  if (!isObject(form)) {
    problems.push(`${path}: must be an object`);
    return null;
  }
  onlyKeys(form, ['label', 'button', 'editable', 'fields'], path, problems);
  const result = {
    name,
    label: text(form.label, `${path}.label`, problems),
    button: buttonOf(form.button, `${path}.button`, languages, problems),
    editable: editableOf(form.editable, `${path}.editable`, problems),
    fields: [],
  };
  if (!Array.isArray(form.fields) || form.fields.length === 0 || !form.fields.every(isObject)) {
    problems.push(`${path}.fields: must list the form's fields, at least one, each an object`);
    return result;
  }
  const names = new Map();
  form.fields.forEach((field, index) => {
    const read = formFieldOf(field, `${path}.fields.${index + 1}`, names, problems);
    if (read) result.fields.push(read);
  });
  const characters = result.fields.reduce((sum, field) => sum + (field.maxLength ?? 0), 0);
  if (characters > FORM_CHARACTERS) {
    problems.push(`${path}.fields: take ${characters} characters together, and a form takes at most ${FORM_CHARACTERS}`);
  }
  return result;
}

// A form's button text, as declared: one text, or on a site in several languages one by locale,
// one for each language, as a type's address may be; null where it declares none.
function buttonOf(button, path, languages, problems) {
  if (button === undefined) return null;
  if (!isObject(button)) return text(button, path, problems);
  if (languages.length < 2) {
    problems.push(`${path}: only a site with several languages gives a form's button a text in each language; give it one text`);
    return null;
  }
  for (const locale of Object.keys(button)) {
    if (!languages.some((language) => language.locale === locale)) problems.push(`${path}.${locale}: is not one of the site's languages`);
  }
  const read = {};
  for (const { locale } of languages) {
    if (Object.hasOwn(button, locale)) read[locale] = text(button[locale], `${path}.${locale}`, problems);
    else problems.push(`${path}: must give a text in each of the site's languages, and gives none in ${locale}`);
  }
  return read;
}

// The texts of a form an editor may change where it is placed, as declared, none by default.
function editableOf(editable, path, problems) {
  if (editable === undefined) return [];
  const known = EDITABLE_FORM_TEXTS.join(', ');
  if (!Array.isArray(editable) || new Set(editable).size !== editable.length) {
    problems.push(`${path}: must list the texts an editor may change where the form is placed, of ${known}, each once`);
    return [];
  }
  for (const name of editable.filter((one) => !EDITABLE_FORM_TEXTS.includes(one))) {
    problems.push(`${path}: ${JSON.stringify(name)} is no text an editor may change where the form is placed; an editor may change its ${known}`);
  }
  return editable.filter((one) => EDITABLE_FORM_TEXTS.includes(one));
}

function formFieldOf(field, path, names, problems) {
  onlyKeys(field, ['name', 'label', 'kind', 'required', 'maxLength', 'options', 'help'], path, problems);
  const { name, kind } = field;
  if (typeof name !== 'string' || !FORM_FIELD_NAME.test(name)) {
    problems.push(`${path}.name: a field's name must be lowercase letters, digits and underscores, starting with a letter`);
  } else if (names.has(name)) {
    problems.push(`${path}.name: ${name} is also the name of ${names.get(name)}`);
  } else {
    names.set(name, path);
  }
  const { label, labelParts } = linkedLabel(text(field.label, `${path}.label`, problems), `${path}.label`, problems);
  if (typeof kind !== 'string' || !Object.hasOwn(FIELD_KINDS, kind)) {
    const known = Object.keys(FIELD_KINDS);
    problems.push(`${path}.kind: ${JSON.stringify(kind)} is not one of ${known.slice(0, -1).join(', ')} and ${known.at(-1)}`);
    return null;
  }
  const rules = FIELD_KINDS[kind];
  const article = /^[aeiou]/.test(kind) ? 'an' : 'a';
  for (const rule of ['required', 'maxLength', 'options', 'help']) {
    if (field[rule] !== undefined && !rules.rules.includes(rule)) {
      const always = rules.required ? ', which must always be ticked' : '';
      const taken = rules.rules.length === 1 ? rules.rules[0] : `${rules.rules.slice(0, -1).join(', ')} and ${rules.rules.at(-1)}`;
      problems.push(`${path}.${rule}: is not a rule ${article} ${kind} field takes${always}; it takes ${taken}`);
    }
  }
  const read = { name, label, labelParts, kind, required: rules.required ?? (rules.rules.includes('required') ? flag(field.required, `${path}.required`, problems) : false) };
  if (rules.rules.includes('maxLength')) {
    const given = field.maxLength ?? rules.maxLength;
    if (!Number.isSafeInteger(given) || given < 1 || given > rules.most) {
      problems.push(`${path}.maxLength: must be a whole number from 1 to ${rules.most}, the most ${article} ${kind} field takes`);
    }
    read.maxLength = given;
  }
  if (rules.rules.includes('options')) {
    const { options } = field;
    if (!Array.isArray(options) || options.length === 0 || !options.every((option) => typeof option === 'string' && option.trim() !== '')
      || new Set(options).size !== options.length) {
      problems.push(`${path}.options: must list the choices, each a different, non-empty string`);
      read.options = [];
    } else {
      read.options = [...options];
    }
  }
  read.help = field.help === undefined ? null : text(field.help, `${path}.help`, problems);
  return read;
}

// A link in a form field's label, written as Markdown writes one: [words](address).
const LABEL_LINK = /\[([^\]]*)\]\(([^)]*)\)/g;

// A form field's label, which may hold links, written as Markdown links, and nothing else of
// Markdown, each to an address a menu's entry may have: { label, labelParts }, `label` its words
// without the links, as a submission keeps them, and `labelParts` the parts a form draws, each a
// text or { href, text }, as a form's outcomes are given.
function linkedLabel(given, path, problems) {
  if (typeof given !== 'string') return { label: given, labelParts: [] };
  const labelParts = [];
  let at = 0;
  for (const { 0: whole, 1: words, 2: href, index } of given.matchAll(LABEL_LINK)) {
    if (!isLinkAddress(href)) {
      problems.push(`${path}: links to ${JSON.stringify(href)}, which is no address a link in a label may have: a path of the site's own, such as /privacy-policy/, or one that starts with https://, http://, mailto: or tel:`);
    } else if (words.trim() === '') {
      problems.push(`${path}: links to ${href} with no words to follow it by`);
    }
    if (index > at) labelParts.push(given.slice(at, index));
    labelParts.push({ href, text: words });
    at = index + whole.length;
  }
  if (at < given.length) labelParts.push(given.slice(at));
  return { label: labelParts.map((part) => (typeof part === 'string' ? part : part.text)).join(''), labelParts };
}

// The departures a site may make from the consent rules, each by
// its name, and whether it names a service. The list is closed: nothing
// else of the rules can be departed from.
export const DEPARTURES = Object.freeze({
  // The tag manager loads before the visitor's choice, its tags reading the
  // consent signal.
  tagManagerBeforeConsent: { service: false },
  // A named service counts as necessary, which is always on.
  necessaryService: { service: true },
  // The statistics service counts from the first page view, storing and
  // reading nothing in the visitor's browser until the visitor allows
  // statistics; `privacySignals` says whether a browser that sends Global
  // Privacy Control or Do Not Track is not counted at all (`stop`) or
  // counted the same way (`ignore`).
  statisticsWithoutStorageBeforeConsent: { service: false, privacySignals: true },
});

// What a departure's `privacySignals` may say.
export const PRIVACY_SIGNALS = Object.freeze(['stop', 'ignore']);

// What the site declares of consent: its departures from the consent rules,
// each with its reason, which the site repository keeps as the record of a
// deliberate departure, and the domain the choice is kept on.
function consentOf(consent, problems) {
  if (consent === undefined) return { departures: [], domain: null };
  if (!isObject(consent)) {
    problems.push('consent: must be an object');
    return { departures: [], domain: null };
  }
  onlyKeys(consent, ['departures', 'domain'], 'consent', problems);
  const domain = consentDomainOf(consent.domain, problems);
  if (consent.departures === undefined) return { departures: [], domain };
  if (!Array.isArray(consent.departures) || !consent.departures.every(isObject)) {
    problems.push('consent.departures: must list the departures, each an object');
    return { departures: [], domain };
  }
  const departures = [];
  const seen = new Map();
  consent.departures.forEach((declared, index) => {
    const path = `consent.departures.${index + 1}`;
    const read = departureOf(declared, path, problems);
    if (!read) return;
    const key = `${read.departure}\n${read.service ?? ''}`;
    if (seen.has(key)) problems.push(`${path}: departs as ${seen.get(key)} does`);
    else seen.set(key, path);
    departures.push(read);
  });
  return { departures, domain };
}

// The domain the consent choice is kept on, in a cookie every site below it
// reads: a host name in lowercase, the site's own host or a domain above it,
// which the build checks, of at least two labels, and never a public suffix
// or a shared domain of the Public Suffix List, or a name above one, since
// a cookie there would reach anyone's sites; null where none is given.
const DOMAIN_LABEL = '[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?';
const CONSENT_DOMAIN = new RegExp(`^(?:${DOMAIN_LABEL}\\.)+(?:[a-z]{2,63}|xn--[a-z0-9-]{1,59})$`);

function consentDomainOf(domain, problems) {
  if (domain === undefined) return null;
  if (typeof domain !== 'string' || !CONSENT_DOMAIN.test(domain) || domain.length > 253) {
    problems.push(`consent.domain: ${JSON.stringify(domain)} must be a domain name in lowercase, such as example.com, its xn-- form for letters outside a to z`);
    return null;
  }
  const shared = suffixTakenIn(domain);
  if (shared) {
    problems.push(`consent.domain: ${domain} ${shared.suffix === domain ? 'is' : `takes in ${shared.suffix}, which is`} a ${shared.section === 'icann' ? 'public suffix, under which anyone may register a domain' : 'shared domain, under which anyone may have a host'}; name the site's own domain, such as example.com`);
    return null;
  }
  return domain;
}

function departureOf(declared, path, problems) {
  onlyKeys(declared, ['departure', 'service', 'reason', 'privacySignals'], path, problems);
  const { departure, service, reason, privacySignals } = declared;
  const kind = typeof departure === 'string' && Object.hasOwn(DEPARTURES, departure) ? DEPARTURES[departure] : null;
  if (!kind) {
    const allowed = Object.keys(DEPARTURES);
    problems.push(`${path}.departure: ${JSON.stringify(departure)} is not a departure the core allows; it allows ${allowed.slice(0, -1).join(', ')} and ${allowed.at(-1)}`);
  }
  if (typeof reason !== 'string' || reason.trim() === '') problems.push(`${path}.reason: must say why the site departs from the consent rules`);
  if (kind?.service && (typeof service !== 'string' || !SERVICE_ID.test(service))) {
    problems.push(`${path}.service: must name the service that counts as necessary, by its id`);
  } else if (kind && !kind.service && service !== undefined) {
    problems.push(`${path}.service: names no service in this departure`);
  }
  if (kind?.privacySignals && !PRIVACY_SIGNALS.includes(privacySignals)) {
    problems.push(`${path}.privacySignals: must say whether Global Privacy Control or Do Not Track stops the counting altogether, "stop", or not, "ignore"`);
  } else if (kind && !kind.privacySignals && privacySignals !== undefined) {
    problems.push(`${path}.privacySignals: is no part of this departure`);
  }
  if (!kind) return null;
  if (kind.service) return { departure, service, reason };
  return kind.privacySignals ? { departure, reason, privacySignals } : { departure, reason };
}

// A service's id in the service registry, as the rule data names an embed's
// service.
export const SERVICE_ID = /^[a-z][a-z0-9-]*$/;

// The site's languages, as the read form gives them: its one language
//, none for a description that declares none, or its several
//.
function languagesOf({ language, languages }, problems) {
  if (languages !== undefined) {
    if (language !== undefined) problems.push('languages: a site declares its one language in language or its several in languages, not both');
    return severalLanguages(languages, problems);
  }
  if (language === undefined) return [];
  if (typeof language === 'string' && LOCALE.test(language)) return [{ locale: language, tag: languageTag(language), prefix: null, main: true }];
  problems.push(`language: ${JSON.stringify(language)} is not a locale, such as sv_SE or fi`);
  return [];
}

// The language the editor's interface takes where an editor has chosen none
// (ADR 0066): the one the site declares, one Konzilo's interface comes in, else
// the site's main language where the core has a catalogue for it, else British
// English.
function interfaceLanguageOf(declared, language, problems) {
  if (declared === undefined) return catalogueFor(language);
  if (INTERFACE_LANGUAGES.includes(declared)) return declared;
  problems.push(`interfaceLanguage: ${JSON.stringify(declared)} is not a language Konzilo's interface comes in, which are ${interfaceLanguagesNamed()}`);
  return catalogueFor(language);
}

// Several languages, locales in order, the main language first.
function severalLanguages(languages, problems) {
  const locales = Array.isArray(languages) ? languages : [];
  const seen = new Map();
  const tags = new Map();
  const read = [];
  locales.forEach((locale, index) => {
    const path = `languages.${index + 1}`;
    if (typeof locale !== 'string' || !LOCALE.test(locale)) {
      problems.push(`${path}: ${JSON.stringify(locale)} is not a locale, such as "sv_SE" or "en_GB"`);
      return;
    }
    if (seen.has(locale)) {
      problems.push(`${path}: ${locale} is also ${seen.get(locale)}`);
      return;
    }
    seen.set(locale, path);
    const tag = languageTag(locale);
    if (tags.has(tag)) {
      problems.push(`${path}: ${locale} gives the language tag ${tag}, as ${tags.get(tag)} does`);
      return;
    }
    tags.set(tag, path);
    read.push({ locale, tag });
  });
  if (locales.length < 2) {
    problems.push('languages: must list at least two languages, locales such as "sv_SE", the main language first; a site with one declares it in language');
  }
  return read.map(({ locale, tag }, index) => ({ locale, tag, prefix: prefixOf(tag, read), main: index === 0 }));
}

// A language's prefix:
// the language subtag, unless another of the site's locales starts with it.
function prefixOf(tag, languages) {
  const subtag = tag.split('-')[0];
  const variants = languages.filter(({ locale }) => locale.startsWith(subtag));
  return (variants.length > 1 ? tag : subtag).toLowerCase();
}

// The widths uploads are checked against, which a site with a featured
// image, images in body text or a sharing image must give.
function imagesOf(images, types, problems) {
  const having = (has) => Object.values(types).find((type) => type && has(type));
  const featured = having((type) => type.fields.some((field) => field.kind === 'image'));
  const inBody = having((type) => type.elements.includes('image'));
  const sharing = having((type) => type.fields.some((field) => field.kind === 'seo'));
  if (images === undefined) {
    const widths = 'images: must give the smallest width and the display width, since';
    // A built-in type's fields are the core's, which the site does not declare.
    const builtIn = (type, part) => `the built-in ${type.name} has ${part}`;
    if (featured) problems.push(`${widths} ${featured.builtIn ? builtIn(featured, 'a main image') : `types.${featured.name}.fields.image is a featured image`}`);
    else if (inBody) problems.push(`${widths} types.${inBody.name}.elements holds image, images in body text`);
    else if (sharing) problems.push(`${widths} ${sharing.builtIn ? builtIn(sharing, 'the search and sharing fields, with a sharing image') : `types.${sharing.name}.fields.seo holds a sharing image`}`);
    return null;
  }
  if (!isObject(images)) {
    problems.push('images: must be an object');
    return null;
  }
  onlyKeys(images, ['smallestWidth', 'displayWidth'], 'images', problems);
  const width = (key) => {
    const value = images[key];
    if (Number.isSafeInteger(value) && value >= 1) return value;
    problems.push(`images.${key}: must be a whole number of pixels, at least 1`);
    return null;
  };
  const [smallestWidth, displayWidth] = [width('smallestWidth'), width('displayWidth')];
  if (smallestWidth !== null && displayWidth !== null && displayWidth < smallestWidth) {
    problems.push(`images.displayWidth: must be at least the smallest width, ${smallestWidth}`);
  }
  return { smallestWidth, displayWidth };
}

// The content collections of the site's own content files, beside those of
// its types and taxonomies, by what the collection holds.
const siteCollections = {
  menus: 'the site\'s menus',
  settings: 'the site settings',
  consent: 'the service registry',
  [IMAGE_LIBRARY_FOLDER]: 'the image library',
};

// A menu: its name is the file of its entries and its entry in the
// collection `menus`, and its label is the place's name.
function menuOf(name, menu, path, problems) {
  if (!/^[a-z][a-z0-9-]*$/.test(name)) {
    problems.push(`${path}: a menu's name must be lowercase letters, digits and hyphens, starting with a letter`);
  }
  if (!isObject(menu)) {
    problems.push(`${path}: must be an object`);
    return null;
  }
  onlyKeys(menu, ['label'], path, problems);
  return { name, label: label(menu.label, `${path}.label`, problems) };
}

// The attributes of every post list, which no option of a
// presentation may take, since a list writes the options of its
// presentation as attributes of its own beside them: those of each block
// the rule data writes as a directive that takes the options of the
// presentation an attribute names (`optionsOf`).
const LIST_ATTRIBUTES = new Set(Object.values(rules.elements)
  .filter((rule) => rule.directive?.optionsOf)
  .flatMap((rule) => Object.keys(rule.directive.attributes ?? {})));

// What a directive's attribute is never called.
const RESERVED_ATTRIBUTES = ['id', 'class', 'content'];

// The value types of a presentation's options, those a directive's
// attribute takes, and the controls each may be shown with.
const optionControls = { string: SETTING_TYPES.string, integer: SETTING_TYPES.integer, boolean: SETTING_TYPES.boolean };

// A presentation: a way the site's design shows a post list, its
// label the name it is offered by, and its options in the form of a
// setting, which a list writes as attributes of its own. An option that two
// presentations both have is one attribute, of one type, which
// `optionTypes` keeps by name.
function presentationOf(name, presentation, path, optionTypes, problems) {
  if (!/^[a-z][a-z0-9-]*$/.test(name)) {
    problems.push(`${path}: a presentation's name must be lowercase letters, digits and hyphens, starting with a letter`);
  }
  if (!isObject(presentation)) {
    problems.push(`${path}: must be an object`);
    return null;
  }
  onlyKeys(presentation, ['label', 'options'], path, problems);
  const result = { name, label: label(presentation.label, `${path}.label`, problems), options: [] };
  for (const [option, declared] of entries(presentation.options, `${path}.options`, problems, false)) {
    const where = `${path}.options.${option}`;
    if (!/^[a-z][a-zA-Z0-9]*$/.test(option)) {
      problems.push(`${where}: an option's name must be letters and digits, starting with a lowercase letter`);
      continue;
    }
    if (RESERVED_ATTRIBUTES.includes(option)) {
      problems.push(`${where}: no attribute of a directive is called id, class or content; give the option another name`);
      continue;
    }
    if (LIST_ATTRIBUTES.has(option)) {
      problems.push(`${where}: is an attribute of every post list; give the option another name`);
      continue;
    }
    if (!isObject(declared)) {
      problems.push(`${where}: must be an object`);
      continue;
    }
    const read = ownField(option, declared, where, problems, undefined, optionControls);
    const other = optionTypes.get(option);
    if (other && Object.hasOwn(optionControls, read.type) && other.type !== read.type) {
      problems.push(`${where}: is an option of ${other.presentation} too, of the type ${other.type}; give it the same type or another name`);
    } else if (!other && Object.hasOwn(optionControls, read.type)) {
      optionTypes.set(option, { presentation: name, type: read.type });
    }
    result.options.push(read);
  }
  return result;
}

// A site setting: a value of the site's own, in the form of a type's field,
// and `translated: true` for a text with a value in each of the site's
// languages (translatedOf()). Konzilo's own groups are kept and written
// under their names.
function settingOf(name, setting, path, groups, problems) {
  if (!fieldName(name, path, problems)) return null;
  if (IDENTITY.includes(name)) {
    problems.push(`${path}: ${name} is where the site settings hold the site's ${name}; give the setting another name`);
    return null;
  }
  const group = groups.find((found) => found.name === name);
  if (group) {
    problems.push(`${path}: ${name} is the name of Konzilo's own settings group ${JSON.stringify(labelIn(group.label, SOURCE_LANGUAGE))}; give the setting another name`);
    return null;
  }
  if (!isObject(setting)) {
    problems.push(`${path}: must be an object`);
    return null;
  }
  const { translated, ...declared } = setting;
  const read = ownField(name, declared, path, problems);
  if (translatedOf(translated, read, path, problems)) read.translated = true;
  return read;
}

// Whether a setting, as read, is translated: it has a value in
// each of the site's languages, kept per language and written into each
// language's settings file, where every other setting has one value for
// every language. Only a text shown as text or a text area is, as a
// visitor reads it; `translated` is true, false or left out. A site in one
// language has the one value. Settings groups of Konzilo's own declare it
// the same way (settings-groups.js).
export function translatedOf(translated, read, path, problems) {
  if (translated === undefined || translated === false) return false;
  if (translated !== true) {
    problems.push(`${path}.translated: must be true or false`);
    return false;
  }
  if (read.type !== 'string' || !['text', 'textarea'].includes(read.control)) {
    problems.push(`${path}.translated: only a text shown as text or a text area is translated`);
    return false;
  }
  return true;
}

// A type, the site's own or a built-in one by its name (format/built-in-types.js): the
// site gives a built-in type all it gives its own but the core's fields, and its label
// and plural only where it wants its own.
function typeOf(name, type, path, site, problems) {
  if (!/^[a-z][a-z0-9_-]{0,19}$/.test(name)) {
    problems.push(`${path}: a post type's name must be lowercase letters, digits, hyphens and underscores, starting with a letter, at most 20`);
  }
  if (!isObject(type)) {
    problems.push(`${path}: must be an object`);
    return null;
  }
  const builtIn = Object.hasOwn(BUILT_IN_TYPES, name) ? BUILT_IN_TYPES[name] : null;
  onlyKeys(type, ['label', 'plural', 'collection', 'address', 'feed', 'hierarchical', 'search', 'elements', 'fields', 'editor', 'structuredDataTypes'], path, problems);
  if (type.editor !== undefined && !EDITORS.includes(type.editor)) problems.push(`${path}.editor: must be ${EDITORS.join(' or ')}, how an editor writes the body`);
  if (builtIn && !builtIn.hierarchical && type.hierarchical !== undefined) {
    problems.push(`${path}.hierarchical: an ${name} has no parent; only a page and a canvas may be hierarchical`);
  }
  const hierarchical = builtIn && !builtIn.hierarchical ? false : flag(type.hierarchical, `${path}.hierarchical`, problems);
  const address = addressOf(name, type.address, hierarchical, `${path}.address`, site.addresses, problems);
  const labelOf = (key) => (builtIn && type[key] === undefined ? catalogueLabel(builtIn[key]) : label(type[key], `${path}.${key}`, problems));
  const result = {
    name,
    builtIn: builtIn ? name : null,
    label: labelOf('label'),
    plural: labelOf('plural'),
    collection: collectionOf(type.collection, `${path}.collection`, site.collections, problems),
    address,
    feed: feedAddressOf(type.feed, `${path}.feed`, false, problems),
    hierarchical,
    search: takesPart(type.search, address, site.addresses.searched, `${path}.search`, problems),
    elements: elementsOf(type.elements, `${path}.elements`, site.rules, problems),
    editor: EDITORS.includes(type.editor) ? type.editor : 'text',
    structuredDataTypes: structuredDataTypesOf(name, type.structuredDataTypes, builtIn, `${path}.structuredDataTypes`, problems),
    fields: [],
  };
  const declaredFields = entries(type.fields, `${path}.fields`, problems, false);
  const own = builtIn ? declaredFields.filter(([field, declared]) => ownOfBuiltIn(name, field, declared, `${path}.fields.${field}`, problems)) : declaredFields;
  const taken = new Set();
  for (const [field, declared] of builtIn ? fieldsWith(name, own) : own) {
    const read = fieldOf(field, declared, `${path}.fields.${field}`, site.taxonomies, problems);
    if (!read) continue;
    if (read.kind === 'terms' && read.taxonomy) {
      if (taken.has(read.taxonomy.name)) problems.push(`${path}.fields.${field}: a second field for the taxonomy ${read.taxonomy.name}`);
      taken.add(read.taxonomy.name);
    }
    result.fields.push(read);
  }
  if (result.feed !== null) {
    if (result.address === null) problems.push(`${path}.feed: a feed links each post to its page, and ${name} has no address`);
    if (!hasDate(result)) problems.push(`${path}.feed: a feed lists posts by their date, and ${name} has none${builtIn ? '' : '; declare "date": {} among its fields'}`);
  }
  return result;
}

// Whether a field a site declares on a built-in type is its own, which it is unless it
// is one of the type's core fields, declared again or left out, or names a field of the
// core's that the type does not take.
function ownOfBuiltIn(type, name, declared, path, problems) {
  if (Object.hasOwn(BUILT_IN_TYPES[type].fields, name)) {
    problems.push(declared === false || declared === null
      ? `${path}: is one of the core's fields of the built-in ${type}, which every ${type} has; a site cannot leave it out`
      : `${path}: is one of the core's fields of the built-in ${type}, which has it without being declared; leave it out of fields`);
    return false;
  }
  if (Object.hasOwn(CORE_FIELDS, name) || name === SEO_FIELD) {
    problems.push(`${path}: names a field of the core's, which the built-in ${type} does not take; give a field of the site's own another name`);
    return false;
  }
  return true;
}

// The structured data types a type offers its posts, its default first: a built-in type's are
// the core's, and a type of the site's own's those it declares, each once, else what a page
// offers.
function structuredDataTypesOf(name, declared, builtIn, path, problems) {
  if (builtIn) {
    if (declared !== undefined) problems.push(`${path}: the built-in ${name} offers the core's structured data types; leave it out`);
    return builtIn.structuredDataTypes;
  }
  if (declared === undefined) return EVERY_STRUCTURED_DATA_TYPE;
  const known = Array.isArray(declared) && declared.length > 0 && new Set(declared).size === declared.length && declared.every((one) => SCHEMA_TYPES.includes(one));
  if (known) return Object.freeze([...declared]);
  problems.push(`${path}: must list the structured data types the type offers, each once, its default first, among ${SCHEMA_TYPES.slice(0, -1).join(', ')} and ${SCHEMA_TYPES.at(-1)}`);
  return EVERY_STRUCTURED_DATA_TYPE;
}

// A field of the site's own on a built-in type, a value, is one the editor keeps in a group of the
// site's own fields, in every form of a built-in type a field of its name stands in. The editor
// reads every built-in type's source files in one format, which goes by a field's name alone,
// since it is told nothing of a file's type (cms/config.js, ADR 0071). A term is a relation, which
// that group cannot hold, so no term on a built-in type has such a name. A type of the site's own
// has its files read in a format of their own, which holds no such group.
function ownFieldsOf(types, problems) {
  const builtIn = Object.values(types).filter((one) => one?.builtIn);
  const owners = new Map();
  for (const type of builtIn) {
    for (const field of type.fields.filter((one) => one.kind === 'meta')) if (!owners.has(field.name)) owners.set(field.name, type.name);
  }
  for (const type of builtIn) {
    for (const field of type.fields.filter((one) => one.kind === 'terms' && owners.has(one.name))) {
      problems.push(`types.${type.name}.fields.${field.name}: the built-in ${owners.get(field.name)} has a field of the site's own by this name, which the editor keeps among the site's own fields on every built-in type; give this term another name`);
    }
  }
}

function taxonomyOf(name, taxonomy, path, { collections, addresses }, problems) {
  if (!/^[a-z][a-z0-9_]{0,31}$/.test(name)) {
    problems.push(`${path}: a taxonomy's name must be lowercase letters, digits and underscores, starting with a letter, at most 32`);
  }
  if (!isObject(taxonomy)) {
    problems.push(`${path}: must be an object`);
    return null;
  }
  onlyKeys(taxonomy, ['label', 'plural', 'collection', 'hierarchical', 'address', 'feed'], path, problems);
  const hierarchical = flag(taxonomy.hierarchical, `${path}.hierarchical`, problems);
  return {
    name,
    builtIn: null,
    label: label(taxonomy.label, `${path}.label`, problems),
    plural: label(taxonomy.plural, `${path}.plural`, problems),
    collection: collectionOf(taxonomy.collection, `${path}.collection`, collections, problems),
    hierarchical,
    address: termAddressOf(name, taxonomy.address, hierarchical, `${path}.address`, addresses, problems),
    feed: feedAddressOf(taxonomy.feed, `${path}.feed`, true, problems),
  };
}

// A built-in taxonomy, which comes with the built-in article (format/built-in-types.js):
// its shape is the core's, and a site gives it an address and a feed, and its label and
// plural where it wants its own.
function builtInTaxonomyOf(name, taxonomy, path, { collections, addresses }, problems) {
  const builtIn = BUILT_IN_TAXONOMIES[name];
  if (!isObject(taxonomy)) {
    problems.push(`${path}: must be an object`);
    taxonomy = {};
  }
  for (const key of Object.keys(taxonomy)) {
    if (key === 'collection' || key === 'hierarchical') problems.push(`${path}.${key}: the shape of the built-in taxonomy ${name} is the core's; a site gives it an address, a feed and a label of its own, if any`);
    else if (!['label', 'plural', 'address', 'feed'].includes(key)) problems.push(`${path}.${key}: is not part of the site description`);
  }
  const labelOf = (key) => (taxonomy[key] === undefined ? catalogueLabel(builtIn[key]) : label(taxonomy[key], `${path}.${key}`, problems));
  return {
    name,
    builtIn: name,
    label: labelOf('label'),
    plural: labelOf('plural'),
    collection: collectionOf(builtIn.collection, `${path}.collection`, collections, problems),
    hierarchical: builtIn.hierarchical,
    address: termAddressOf(name, taxonomy.address, builtIn.hierarchical, `${path}.address`, addresses, problems),
    feed: feedAddressOf(taxonomy.feed, `${path}.feed`, true, problems),
  };
}

// The address of each term's page of a taxonomy, or null for a taxonomy
// whose terms have none, which is every taxonomy that declares none: one path from the site's root, ending in `{slug}`, the term's slug,
// or in a hierarchical taxonomy `{slug}` or `{path}`, the slugs of its
// parents and its own, held to a type's rules. No type or other taxonomy has it in any of
// the site's languages, and a site in several languages gives its terms'
// pages one address, in its main language.
function termAddressOf(name, address, hierarchical, path, addresses, problems) {
  if (address === undefined) return null;
  if (!onePath(address, { name, hierarchical, kind: 'taxonomy' }, path, problems)) return null;
  const { languages } = addresses;
  for (const { locale } of languages.length > 0 ? languages : [{ locale: null }]) claim(address, locale, path.replace(/\.address$/, ''), path, addresses, problems);
  return address;
}

// Whether a type (as read) declares a date among its fields.
function hasDate(type) {
  return type.fields.some((field) => field.kind === 'date');
}

// The address of a type's feed, or of the feed of each term of a taxonomy
// (`term`), as declared: a path from the site's root, ending in
// `/`, whose segments are lowercase letters, digits, hyphens and
// underscores, and in a taxonomy's one of them `{slug}`, the term's slug,
// never the last, which is the form of a post's or a term's own page. Null
// for none, and for one with a problem.
function feedAddressOf(feed, path, term, problems) {
  if (feed === undefined) return null;
  const example = term ? '"/category/{slug}/feed/"' : '"/feed/"';
  if (typeof feed !== 'string' || !/^(\/([a-z0-9_][a-z0-9_-]*|\{slug\}))+\/$/.test(feed)) {
    problems.push(`${path}: must be a path from the site's root that ends in /, such as ${example}, in lowercase letters, digits, hyphens and underscores${term ? ', with {slug} for the term\'s slug' : ''}`);
    return null;
  }
  const segments = feed.slice(1, -1).split('/');
  const slugs = segments.filter((segment) => segment === '{slug}').length;
  if (!term && slugs > 0) {
    problems.push(`${path}: a type has one feed, so its address holds no {slug}, such as ${example}`);
    return null;
  }
  if (term && slugs !== 1) {
    problems.push(`${path}: a taxonomy has a feed for each term, so its address holds {slug}, the term's slug, once, such as ${example}`);
    return null;
  }
  if (term && segments.at(-1) === '{slug}') {
    problems.push(`${path}: ends in {slug}, where a post or a term's page would be; end it in a segment of its own, such as ${example}`);
    return null;
  }
  const below = [RESERVED_PREFIX, ...rules.addresses.reserved.filter((entry) => entry.endsWith('/*')).map((entry) => entry.slice(0, -1))]
    .find((prefix) => feed.startsWith(prefix));
  if (below !== undefined) {
    problems.push(`${path}: ${feed} lies below ${below}, which the site keeps for itself; give the feed another address`);
    return null;
  }
  return feed;
}

// The feeds of a site against each other and against what they list: a
// taxonomy's feeds hold the posts of the types that take it and have a date
// and an address, so one such type must; and no two feeds may have one
// address, which they could where every segment of one is the other's or
// `{slug}`. Each pair is told once, at the later.
function feedsOf(types, taxonomies, problems) {
  for (const taxonomy of Object.values(taxonomies)) {
    if (taxonomy?.feed == null) continue;
    const listed = Object.values(types).some((type) => type !== null && type.address !== null && hasDate(type)
      && type.fields.some((field) => field.kind === 'terms' && field.taxonomy?.name === taxonomy.name));
    if (!listed) {
      problems.push(`taxonomies.${taxonomy.name}.feed: a term's feed holds the posts of the types that take ${taxonomy.name} and have a date and an address, and no type does`);
    }
  }
  const feeds = [
    ...Object.values(types).filter((type) => type?.feed != null).map((type) => [`types.${type.name}`, type.feed]),
    ...Object.values(taxonomies).filter((taxonomy) => taxonomy?.feed != null).map((taxonomy) => [`taxonomies.${taxonomy.name}`, taxonomy.feed]),
  ];
  const meet = (a, b) => {
    const [x, y] = [a.slice(1, -1).split('/'), b.slice(1, -1).split('/')];
    return x.length === y.length && x.every((segment, i) => segment === y[i] || segment === '{slug}' || y[i] === '{slug}');
  };
  feeds.forEach(([path, feed], index) => {
    const other = feeds.slice(0, index).find(([, earlier]) => meet(earlier, feed));
    if (other) problems.push(`${path}.feed: ${feed} could be the address of the feed of ${other[0]} too, at ${other[1]}`);
  });
}

// A template reads a field or a setting as `entry.data.<name>`.
export function fieldName(name, path, problems) {
  if (/^[a-z][a-zA-Z0-9_]*$/.test(name)) return true;
  problems.push(`${path}: a field's name must be letters, digits and underscores, starting with a lowercase letter`);
  return false;
}

function fieldOf(name, field, path, taxonomies, problems) {
  if (!fieldName(name, path, problems)) return null;
  if (name === 'title') {
    problems.push(`${path}: every post has its title; it is not declared`);
    return null;
  }
  if (name === OLD_ADDRESSES) {
    problems.push(`${path}: a post's old addresses are kept under this name; it is not declared`);
    return null;
  }
  if (name === OTHER_ADDRESSES) {
    problems.push(`${path}: a post's other addresses are kept under this name; it is not declared`);
    return null;
  }
  if (name === TRANSLATION_KEY) {
    problems.push(`${path}: a post's translation set is kept under this name; it is not declared`);
    return null;
  }
  if (Object.hasOwn(SEO_PARTS, name)) {
    problems.push(`${path}: a source file keeps a group of the search and sharing fields under this name; give the field another`);
    return null;
  }
  if (!isObject(field)) {
    problems.push(`${path}: must be an object`);
    return null;
  }
  if (Object.hasOwn(CORE_FIELDS, name)) {
    onlyKeys(field, CORE_FIELDS[name], path, problems);
    return { name, kind: name, required: flag(field.required, `${path}.required`, problems) };
  }
  if (name === SEO_FIELD) {
    if (['label', 'type', 'control', 'options'].some((key) => Object.hasOwn(field, key))) {
      problems.push(`${path}: the search and sharing fields are kept under this name; give the field of the site's own another`);
      return null;
    }
    onlyKeys(field, [], path, problems);
    return { name, kind: 'seo', keys: SEO_KEYS, required: false };
  }
  if (Object.hasOwn(field, 'taxonomy')) {
    onlyKeys(field, ['taxonomy', 'required', 'most'], path, problems);
    const taxonomy = Object.hasOwn(taxonomies, field.taxonomy) ? taxonomies[field.taxonomy] : null;
    if (!taxonomy) problems.push(`${path}.taxonomy: ${JSON.stringify(field.taxonomy)} is not a taxonomy the site description declares`);
    const most = field.most === undefined ? null : Number.isSafeInteger(field.most) && field.most > 0 ? field.most : undefined;
    if (most === undefined) problems.push(`${path}.most: must be a whole number from 1, the most terms a post takes`);
    return { name, kind: 'terms', taxonomy, required: flag(field.required, `${path}.required`, problems), most: most ?? null };
  }
  return metaField(name, field, path, problems);
}

// A field of the site's own.
function metaField(name, field, path, problems) {
  if (field.type === POST) {
    problems.push(`${path}.type: only a site setting can choose a post; a post's field cannot`);
    return null;
  }
  if (field.type === IMAGE) {
    problems.push(`${path}.type: only a site setting can be an image; a post's field cannot`);
    return null;
  }
  return { kind: 'meta', ...ownField(name, field, path, problems, undefined, FIELD_TYPES) };
}

// A value of the site's own: its label, its type, the control that shows it,
// a select's options, and whether it is required. `whole` names what declares
// it in a problem with its keys: the site description, or the core's
// settings groups (settings-groups.js). `takes`: the types it may have, each
// with its controls; a field's are those of a setting but a post.
export function ownField(name, field, path, problems, whole, takes = SETTING_TYPES) {
  onlyKeys(field, ['label', 'type', 'control', 'options', 'required'], path, problems, whole);
  const result = {
    name,
    label: label(field.label, `${path}.label`, problems),
    type: field.type,
    control: field.control,
    required: flag(field.required, `${path}.required`, problems),
  };
  if (!Object.hasOwn(takes, field.type)) {
    problems.push(`${path}.type: ${JSON.stringify(field.type)} is not one of ${Object.keys(takes).join(', ')}`);
    return result;
  }
  if (!takes[field.type].includes(field.control)) {
    const shown = takes[field.type];
    const list = shown.length === 1 ? shown[0] : `${shown.slice(0, -1).join(', ')} or ${shown.at(-1)}`;
    problems.push(`${path}.control: ${JSON.stringify(field.control)} cannot show a field of the type ${field.type}, which takes ${list}`);
  }
  if (field.type === 'boolean' && field.required !== undefined) {
    problems.push(`${path}.required: a yes-or-no field always has a value`);
  }
  if (field.type === POST && field.required !== undefined) {
    problems.push(`${path}.required: a chosen post can lose its page at any time, and the site then leaves it out, so it cannot be required`);
  }
  if (field.control === 'select' || field.options !== undefined) {
    if (field.control !== 'select') {
      problems.push(`${path}.options: only a field shown as a select has options`);
    } else if (!Array.isArray(field.options) || field.options.length === 0
      || !field.options.every((option) => typeof option === 'string' && option !== '')
      || new Set(field.options).size !== field.options.length) {
      problems.push(`${path}.options: must list the choices, each a different, non-empty string`);
    } else {
      result.options = [...field.options];
    }
  }
  return result;
}

// Whether a type's posts are in the site's search: on a site with
// search, every type with an address is, unless it declares `"search":
// false`; a type without one has no page to find.
function takesPart(declared, address, searched, path, problems) {
  if (declared !== undefined && typeof declared !== 'boolean') {
    problems.push(`${path}: must be true or false`);
    return false;
  }
  if (declared === true && address === null) {
    problems.push(`${path}: a type without an address has no page that search could find; leave search out`);
    return false;
  }
  return searched && address !== null && declared !== false;
}

// The site's search: the public address of its search page, a
// path from the site's root that ends in `/`, or null for a site without
// search. No page of the site's services' is a search page (RESERVED_PREFIX),
// nor any language's start page. A type whose own folder holds the address,
// as /news/{slug}/ holds /news/search/, is refused, since its posts are what
// that folder is for; a type at the root, as /{slug}/ and /{path}/ are,
// could give any address, and the intake refuses the one post that would
// take the search page's (two types' addresses are left to their posts
// the same way).
function searchOf(search, { types, taxonomies, languages }, problems) {
  if (search === undefined) return null;
  if (!isObject(search)) {
    problems.push('search: must be an object that gives the search page\'s address, such as { "address": "/search/" }');
    return null;
  }
  onlyKeys(search, ['address'], 'search', problems);
  const { address } = search;
  if (typeof address !== 'string' || !/^(\/[a-z0-9_][a-z0-9_-]*)+\/$/.test(address)) {
    const given = address === undefined ? '' : `${JSON.stringify(address)} `;
    problems.push(`search.address: ${given}must be a path from the site's root that ends in /, such as "/search/", in lowercase letters, digits, hyphens and underscores`);
    return null;
  }
  if (address.startsWith(RESERVED_PREFIX)) {
    problems.push(`search.address: ${address} lies below ${RESERVED_PREFIX}, where the site's services answer; give the search page another address`);
    return null;
  }
  const start = languages.length > 1 ? languages.find(({ prefix }) => address === `/${prefix}/`) : undefined;
  if (start) {
    problems.push(`search.address: ${address} is the start page of ${start.locale}; give the search page another address`);
    return null;
  }
  for (const type of Object.values(types)) {
    if (!type || type.address === null) continue;
    const given = typeof type.address === 'string' ? [[type.address, `types.${type.name}.address`]]
      : Object.entries(type.address).map(([locale, one]) => [one, `types.${type.name}.address.${locale}`]);
    for (const [pattern, path] of given) {
      const folder = pattern.slice(0, pattern.indexOf('{'));
      if (folder === '/' || address === folder || !address.startsWith(folder)) continue;
      const rest = address.slice(folder.length, -1);
      if (type.hierarchical || !rest.includes('/')) {
        problems.push(`${path}: ${pattern} can give a post the search page's address, ${address}; give the search page an address outside ${folder}`);
      }
    }
  }
  // A term's page is the same.
  for (const taxonomy of Object.values(taxonomies)) {
    if (!taxonomy || taxonomy.address === null) continue;
    const folder = taxonomy.address.slice(0, taxonomy.address.indexOf('{'));
    if (folder === '/' || address === folder || !address.startsWith(folder)) continue;
    if (taxonomy.address.endsWith('/{path}/') || !address.slice(folder.length, -1).includes('/')) {
      problems.push(`taxonomies.${taxonomy.name}.address: ${taxonomy.address} can give a term the search page's address, ${address}; give the search page an address outside ${folder}`);
    }
  }
  return { address };
}


// A type's address, or null for a type without one: one address, or on a
// site with several languages one may be given for each language, as an
// object of the address by locale. A hierarchical type's ends in `{path}`,
// the post's ancestors' slugs and its own, any other's in `{slug}`
// (format/addresses.js). No two types share one in a language; two types
// whose addresses can give one address, as `/{path}/` and `/{slug}/` can,
// leave it to the posts.
function addressOf(name, address, hierarchical, path, addresses, problems) {
  if (address === undefined) return null;
  const { languages } = addresses;
  const type = path.replace(/\.address$/, '');
  const form = { name, hierarchical };
  if (!isObject(address)) {
    if (!onePath(address, form, path, problems)) return null;
    for (const { locale } of languages.length > 0 ? languages : [{ locale: null }]) claim(address, locale, type, path, addresses, problems);
    return address;
  }
  if (languages.length < 2) {
    problems.push(`${path}: only a site with several languages gives a type an address in each language; give it one address`);
    return null;
  }
  for (const locale of Object.keys(address)) {
    if (!languages.some((language) => language.locale === locale)) problems.push(`${path}.${locale}: is not one of the site's languages`);
  }
  const read = {};
  for (const { locale } of languages) {
    if (!Object.hasOwn(address, locale)) {
      problems.push(`${path}: must give an address in each of the site's languages, and gives none in ${locale}`);
    } else if (onePath(address[locale], form, `${path}.${locale}`, problems)) {
      read[locale] = address[locale];
      claim(address[locale], locale, type, `${path}.${locale}`, addresses, problems);
    }
  }
  return read;
}

// Whether an address is one path from the site's root, ending in `{path}/`
// in a hierarchical type and in `{slug}/` in any other; a hierarchical
// taxonomy's (`kind`) may end in either. Each problem names the type or the
// taxonomy.
function onePath(address, { name, hierarchical, kind = 'type' }, path, problems) {
  const [own, other] = hierarchical ? ['{path}', '{slug}'] : ['{slug}', '{path}'];
  const shaped = typeof address === 'string' && /^(\/[a-z0-9_][a-z0-9_-]*)*\/\{(slug|path)\}\/$/.test(address);
  // A term's slug is its own in its taxonomy, so a hierarchical taxonomy's
  // terms may have their pages at their slugs alone too.
  const term = kind === 'taxonomy';
  if (shaped && (address.endsWith(`/${own}/`) || (term && hierarchical))) {
    if (!address.startsWith(RESERVED_PREFIX)) return true;
    problems.push(`${path}: ${address} lies below ${RESERVED_PREFIX}, where the site's services answer; give the ${kind} another address`);
    return false;
  }
  if (shaped) {
    const example = term ? '/category/{slug}/' : hierarchical ? '/pages/{path}/' : '/{slug}/';
    problems.push(`${path}: ${name} is ${hierarchical ? '' : 'not '}hierarchical, so its address ends in /${own}/, not /${other}/, such as "${example}"`);
  } else {
    const ends = term && hierarchical ? '/{slug}/ or /{path}/' : `/${own}/`;
    const examples = term ? '"/category/{slug}/"' : hierarchical ? '"/{path}/" or "/pages/{path}/"' : '"/{slug}/" or "/pages/{slug}/"';
    problems.push(`${path}: must be a path from the site's root that ends in ${ends}, such as ${examples}, in lowercase letters, digits, hyphens and underscores`);
  }
  return false;
}

// An address taken by a type in a language (null for a site with one), told
// once for each pair of types that share one.
function claim(address, locale, type, path, { languages, taken, told }, problems) {
  const key = `${locale}\n${address}`;
  const other = taken.get(key);
  if (other === undefined) {
    taken.set(key, type);
  } else if (!told.has(`${type}\n${other}`)) {
    told.add(`${type}\n${other}`);
    problems.push(`${path}: ${address} is also the address of ${other}${languages.length > 1 ? ` in ${locale}` : ''}`);
  }
}

function collectionOf(collection, path, collections, problems) {
  if (typeof collection !== 'string' || !/^[a-z][a-z0-9-]*$/.test(collection)) {
    problems.push(`${path}: must be lowercase letters, digits and hyphens, starting with a letter`);
    return collection;
  }
  if (collection === MEDIA_FOLDER) {
    problems.push(`${path}: ${MEDIA_FOLDER} is where the masters go; give the collection another name`);
    return collection;
  }
  if (Object.hasOwn(siteCollections, collection)) problems.push(`${path}: ${collection} is the collection of ${siteCollections[collection]}`);
  else if (collections.has(collection)) problems.push(`${path}: ${collection} is also the collection of ${collections.get(collection)}`);
  else collections.set(collection, path.replace(/\.collection$/, ''));
  return collection;
}

// The entries of an object of named declarations, such as the types.
function entries(value, path, problems, required) {
  if (value === undefined && !required) return [];
  if (!isObject(value) || (required && Object.keys(value).length === 0)) {
    problems.push(`${path}: must be an object${required ? ' that declares at least one' : ''}`);
    return [];
  }
  return Object.entries(value);
}

function onlyKeys(object, allowed, path, problems, whole = 'the site description') {
  checkedKeys(object, allowed, path, problems, whole);
}

// A key that is true or false, `fallback` where it is left out.
function flag(value, path, problems, fallback = false) {
  if (value === undefined) return fallback;
  if (typeof value !== 'boolean') problems.push(`${path}: must be true or false`);
  return value === true;
}
